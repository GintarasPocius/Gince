<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Special extends Model
{
    protected $fillable = [
        'title',
        'description',
        'img'
    ];

    public function setCreatedAtAt($value)
    {

    }

    public function setUpdatedAt($value){

    }

}