<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Special;

class SpecialsController extends Controller
{


    public function add()
    {
        return view('pages.add');
    }
    public function main()
    {
        return view('main');
    }
      public function store()
      {


          $this->validate(request(),[
              'title'=>'required','description'=>'required','img'=>'required'
          ]);
          Special::create([
              'title'=>request('title'),
        'description'=>request('body'),
        'img' => request('img')

   ]);
   return redirect('/');


}
}
