<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Problem;

class ProblemsController extends Controller

{

    public function store()
    {


        $this->validate(request(), [
            'vardas' => 'required', 'Tekstas' => 'required'
        ]);
        Problem::create([
            'vardas' => request('vardas'),
            'Tekstas' => request('Tekstas')


        ]);
        return redirect('/');

    }
}