<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Problem extends Model
{

    protected $fillable = [
        'vardas',
        'Tekstas'

    ];
    public function setCreatedAt($value)
    {

    }

    public function setUpdatedAt($value){

    }
}
