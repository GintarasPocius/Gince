<!-- Three -->
<section id="three" class="wrapper style3 special">
    <div class="container">
        <header class="major">
            <h2>Turite problemą? Rašykite mums</h2>
            <p>Esame pasiruošę Jums padėti</p>
        </header>
    </div>
    <div class="container 50%">
        <form action="/problem" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="row uniform">
                <div class="6u 12u$(small)">
                    <input name="vardas" id="name" value="" placeholder="Vardas" type="text">
                </div>
                <div class="6u$ 12u$(small)">
                    <input name="email" id="email" value="" placeholder="El. paštas" type="email">
                </div>
                <div class="12u$">
                    <textarea name="Tekstas" id="message" placeholder="Žinutė" rows="6"></textarea>
                </div>
                <div class="12u$">
                    <ul class="actions">
                        <li><input value="Siųsti" class="special big" type="submit"></li>
                    </ul>
                </div>
            </div>
        </form>
    </div>
</section>