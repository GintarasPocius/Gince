<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AviaSystem</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <!--[if lte IE 8]><script src="<?php echo asset('js/html5shiv.js'); ?>"></script><![endif]-->
    <script src="<?php echo asset('js/jquery.min.js'); ?>"></script>
    <script src="<?php echo asset('js/skel.min.js'); ?>"></script>
    <script src="<?php echo asset('js/skel-layers.min.js'); ?>"></script>
    <script src="<?php echo asset('js/init.js'); ?>"></script>
    <noscript>
        <link rel="stylesheet" href="<?php echo asset('css/skel.css'); ?>"/>
        <link rel="stylesheet" href="<?php echo asset('css/style.css'); ?>" />
        <link rel="stylesheet" href="<?php echo asset('css/style-xlarge.css'); ?>"/>
        <link rel="stylesheet" href="<?php echo asset('css/font-awesome.min.css'); ?>"/>
    </noscript>
</head>
<body class="landing">
<?php echo $__env->make('layout.bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<?php echo $__env->make('layout.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<?php echo $__env->make('layout.One', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<!-- Two -->
<section id="two" class="wrapper style2 special">
    <div class="container">
       <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
        <footer>
            <p>Palikite mums atsiliepimą</p>
            <ul class="actions">
                <li>
                    <a href="#" class="button big">Rašyti</a>
                </li>
            </ul>
        </footer>
    </div>
</section>
<?php echo $__env->make('layout.Three', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
<?php echo $__env->make('layout.Footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;


</body>
</html>