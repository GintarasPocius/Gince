<?php $__env->startSection('content'); ?>
<!-- Two -->
<section id="two" class="wrapper style2 special">
    <div class="container">
        <header class="major">
            <h2>Klientų atsiliepimai</h2>
            <p>Klientai apie mūsų paslaugas</p>
        </header>
        <section class="profiles">
            <div class="row">
                <section class="3u 6u(medium) 12u$(xsmall) profile">
                    <img src="images/profile_placeholder.gif" alt="" />
                    <h4>Vardas</h4>
                    <p>Atsiliepimo tekstas</p>
                </section>
                <section class="3u 6u$(medium) 12u$(xsmall) profile">
                    <img src="images/profile_placeholder.gif" alt="" />
                    <h4>Vardas</h4>
                    <p>Atsiliepimo tekstas</p>
                </section>
                <section class="3u 6u(medium) 12u$(xsmall) profile">
                    <img src="images/profile_placeholder.gif" alt="" />
                    <h4>Vardas</h4>
                    <p>Atsiliepimo tekstas</p>
                </section>
                <section class="3u$ 6u$(medium) 12u$(xsmall) profile">
                    <img src="images/profile_placeholder.gif" alt="" />
                    <h4>Vardas</h4>
                    <p>Atsiliepimo tekstas</p>
                </section>
            </div>
        </section>
        <footer>
            <p>Palikite mums atsiliepimą</p>
            <ul class="actions">
                <li>
                    <a href="#" class="button big">Rašyti</a>
                </li>
            </ul>
        </footer>
    </div>
</section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>