<!-- One -->
<section id="one" class="wrapper style1 special">
    <div class="container">
        <header class="major">
            <h2>Geriausi pasiūlymai</h2>
            <p>Pasirinkite geriausią variantą!</p>
        </header>
        <div class="row 150%">
            <div class="4u 12u$(medium)">
                <section class="box">
                    <i class="icon big rounded color1 fa-cloud"></i>
                    <h3>Pasiulymas 1</h3>
                    <p> Trumpas aprašymas</p>
                </section>
            </div>
            <div class="4u 12u$(medium)">
                <section class="box">
                    <i class="icon big rounded color9 fa-desktop"></i>
                    <h3>Pasiulymas 2</h3>
                    <p>Trumpas aprašymas</p>
                </section>
            </div>
            <div class="4u$ 12u$(medium)">
                <section class="box">
                    <i class="icon big rounded color6 fa-rocket"></i>
                    <h3>Pasiulymas 3</h3>
                    <p>Trumpas aprašymas</p>
                </section>
            </div>
        </div>
    </div>
</section>