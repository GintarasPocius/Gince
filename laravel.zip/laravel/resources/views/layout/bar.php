<nav class="navbar">




    <ul>

        <li><a href="/add">Pridėti pasiūlymą</a></li>
        <li><a href="#">Valdyti pasiūlymus</a></li>
        <li><a href="#">Valdyti atsiliepimus</a></li>
        <li><a href="#">Atsijungti</a></li>
    </ul>
</nav>