
<!-- Footer -->
<footer id="footer">
    <div class="container">
        <section class="links">
            <div class="row">
                <section class="3u 6u(medium) 12u$(small)">
                    <h3>Antraštė tekstas</h3>
                    <ul class="unstyled">
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                    </ul>
                </section>
                <section class="3u 6u$(medium) 12u$(small)">
                    <h3>Antraštė tekstas</h3>
                    <ul class="unstyled">
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                    </ul>
                </section>
                <section class="3u 6u(medium) 12u$(small)">
                    <h3>Antraštė tekstas</h3>
                    <ul class="unstyled">
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                    </ul>
                </section>
                <section class="3u$ 6u$(medium) 12u$(small)">
                    <h3>Antraštė tekstas</h3>
                    <ul class="unstyled">
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                        <li><a href="#">tekstas tekstas tekstas</a></li>
                    </ul>
                </section>
            </div>
        </section>
        <div class="row">
            <div class="8u 12u$(medium)">
                <ul class="copyright">
                    <li>&copy; aviaSYSTEM.</li>
                    <li>Sukurta: <a href="http://templated.co">KITM</a></li>
                </ul>
            </div>
            <div class="4u$ 12u$(medium)">
                <ul class="icons">
                    <li>
                        <a class="icon rounded fa-facebook"><span class="label">Facebook</span></a>
                    </li>
                    <li>
                        <a class="icon rounded fa-twitter"><span class="label">Twitter</span></a>
                    </li>
                    <li>
                        <a class="icon rounded fa-google-plus"><span class="label">Google+</span></a>
                    </li>
                    <li>
                        <a class="icon rounded fa-linkedin"><span class="label">LinkedIn</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>