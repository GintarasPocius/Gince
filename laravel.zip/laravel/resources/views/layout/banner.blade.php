<!-- Banner -->
<section id="banner">
    <h2>aviaSYSTEM</h2>
    <p>Greičiausia aviakompanija pasaulyje</p>
    <ul class="actions">
        <li>
            <a href="#" class="button big">Daugiau</a>
        </li>
    </ul>
</section>