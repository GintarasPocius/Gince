<!-- Header -->
<header id="header">
    <h1><a href="index.html">aviaSYSTEM</a></h1>
    <nav id="nav">




        <ul>

            <li><a href="#">Pagrindinis</a></li>
            <li><a href="#">Pasiūlymai</a></li>
            <li><a href="#" class="button special">Prisijungimas</a></li>
        </ul>
    </nav>
</header>
