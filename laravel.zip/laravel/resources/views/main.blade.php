<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AviaSystem</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <!--[if lte IE 8]><script src="{!! asset('js/html5shiv.js') !!}"></script><![endif]-->
    <script src="{!! asset('js/jquery.min.js') !!}"></script>
    <script src="{!! asset('js/skel.min.js') !!}"></script>
    <script src="{!! asset('js/skel-layers.min.js') !!}"></script>
    <script src="{!! asset('js/init.js') !!}"></script>
    <noscript>
        <link rel="stylesheet" href="{!! asset('css/skel.css') !!}"/>
        <link rel="stylesheet" href="{!! asset('css/style.css') !!}" />
        <link rel="stylesheet" href="{!! asset('css/style-xlarge.css') !!}"/>
        <link rel="stylesheet" href="{!! asset('css/font-awesome.min.css') !!}"/>
    </noscript>
</head>
<body class="landing">
@include('layout.bar');
@include ('layout.header');
@include ('layout.banner');
@include ('layout.One');
<!-- Two -->
<section id="two" class="wrapper style2 special">
    <div class="container">
       @yield('content')
            </div>
        </section>
        <footer>
            <p>Palikite mums atsiliepimą</p>
            <ul class="actions">
                <li>
                    <a href="#" class="button big">Rašyti</a>
                </li>
            </ul>
        </footer>
    </div>
</section>
@include ('layout.Three');
@include ('layout.Footer');


</body>
</html>