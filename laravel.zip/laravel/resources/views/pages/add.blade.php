@extends('main')
@section('content')
    <form action="/store" method="POST" enctype="multipart/form-data">
    {{ csrf_field() }}
        <input type="text" placeholder="Pavadinimas">
        <textarea name="description" id="saugumas" cols="30" rows="10">

        </textarea>
        <input type="file">
        <button type="submit">Pridėti</button>
    </form>









@endsection