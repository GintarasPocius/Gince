<?php

namespace App\Http\Controllers;
use App\Special;
use Illuminate\Http\Request;

class  SpecialController extends Controller
{
    public function main()
        {
            $specials = Special::all();
            return( view('pages.special',compact('specials'));

        }
    public function add()
    {
        return view('pages.add');

    }
    public function request
}











