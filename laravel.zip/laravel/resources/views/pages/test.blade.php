@extends('main')
@section('content')
    <header class="major">
        <h2>Tets</h2>
        <p>Tik testas!</p>
    </header>









    @endsection